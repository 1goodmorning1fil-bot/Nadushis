'use client'

import { useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { formatPrice } from '@/lib/utils'
import toast from 'react-hot-toast'
import Link from 'next/link'
import { Search, Edit2, Trash2, Plus, Save, X } from 'lucide-react'

export default function AdminProductsPage() {
  const qc = useQueryClient()
  const [page, setPage] = useState(1)
  const [search, setSearch] = useState('')
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editPrice, setEditPrice] = useState('')
  const [showCreate, setShowCreate] = useState(false)

  const { data, isLoading } = useQuery({
    queryKey: ['admin-products', page, search],
    queryFn: () => fetch(`/api/products?page=${page}&limit=30&search=${search}`).then(r => r.json()),
  })

  const updatePrice = async (id: string) => {
    try {
      await fetch(`/api/products/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ price: editPrice }),
      })
      toast.success('Цена обновлена')
      setEditingId(null)
      qc.invalidateQueries({ queryKey: ['admin-products'] })
    } catch {
      toast.error('Ошибка обновления')
    }
  }

  const toggleStock = async (id: string, current: boolean) => {
    await fetch(`/api/products/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ inStock: !current }),
    })
    qc.invalidateQueries({ queryKey: ['admin-products'] })
  }

  const deleteProduct = async (id: string) => {
    if (!confirm('Удалить товар?')) return
    await fetch(`/api/products/${id}`, { method: 'DELETE' })
    toast.success('Товар удалён')
    qc.invalidateQueries({ queryKey: ['admin-products'] })
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '36px', color: '#1E6B5E' }}>Товары</h1>
          <p style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: 'rgba(26,26,26,0.5)' }}>
            {data?.pagination?.total?.toLocaleString('ru') ?? '—'} товаров в каталоге
          </p>
        </div>
        <div className="flex gap-3">
          <Link href="/admin/import" className="btn-gold flex items-center gap-2" style={{ fontSize: '12px' }}>
            Импорт CSV/JSON
          </Link>
          <button onClick={() => setShowCreate(true)} className="btn-primary flex items-center gap-2" style={{ fontSize: '12px' }}>
            <Plus size={14} /> Добавить товар
          </button>
        </div>
      </div>

      <div className="relative mb-6" style={{ maxWidth: '400px' }}>
        <Search size={16} style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: '#C9A96E' }} />
        <input
          placeholder="Поиск по названию, бренду..."
          value={search}
          onChange={e => { setSearch(e.target.value); setPage(1) }}
          className="input-luxury"
          style={{ paddingLeft: '40px' }}
        />
      </div>

      <div style={{ background: 'white', border: '1px solid rgba(201,169,110,0.2)' }}>
        <table className="w-full">
          <thead>
            <tr style={{ borderBottom: '1px solid rgba(201,169,110,0.2)' }}>
              {['Фото', 'Название', 'Бренд', 'Цена', 'Остаток', 'Наличие', ''].map(h => (
                <th key={h} style={{ textAlign: 'left', padding: '12px', fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.1em', textTransform: 'uppercase', color: '#C9A96E' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr><td colSpan={7} className="text-center py-12" style={{ fontFamily: 'var(--font-body)', color: 'rgba(26,26,26,0.4)' }}>Загрузка...</td></tr>
            ) : data?.products?.map((p: any) => (
              <tr key={p.id} style={{ borderBottom: '1px solid rgba(201,169,110,0.1)' }}>
                <td style={{ padding: '10px 12px' }}>
                  <div style={{ width: '40px', height: '50px', background: '#F5EDDC', position: 'relative', overflow: 'hidden' }}>
                    {p.images[0] && <img src={p.images[0]} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />}
                  </div>
                </td>
                <td style={{ padding: '10px 12px', fontFamily: 'var(--font-body)', fontSize: '13px', maxWidth: '240px' }}>{p.name}</td>
                <td style={{ padding: '10px 12px', fontFamily: 'var(--font-body)', fontSize: '12px', color: 'rgba(26,26,26,0.6)' }}>{p.brand.name}</td>
                <td style={{ padding: '10px 12px' }}>
                  {editingId === p.id ? (
                    <div className="flex items-center gap-2">
                      <input type="number" value={editPrice} onChange={e => setEditPrice(e.target.value)} className="input-luxury" style={{ width: '90px', padding: '4px 8px', fontSize: '12px' }} autoFocus />
                      <button onClick={() => updatePrice(p.id)}><Save size={14} color="#1E6B5E" /></button>
                      <button onClick={() => setEditingId(null)}><X size={14} color="#999" /></button>
                    </div>
                  ) : (
                    <button onClick={() => { setEditingId(p.id); setEditPrice(String(p.price)) }} className="flex items-center gap-2" style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
                      <span style={{ fontFamily: 'var(--font-display)', fontSize: '15px', color: '#1E6B5E', fontWeight: 600 }}>{formatPrice(p.price)}</span>
                      <Edit2 size={11} color="#C9A96E" />
                    </button>
                  )}
                </td>
                <td style={{ padding: '10px 12px', fontFamily: 'var(--font-mono)', fontSize: '12px' }}>{p.stockQty}</td>
                <td style={{ padding: '10px 12px' }}>
                  <button onClick={() => toggleStock(p.id, p.inStock)}
                    style={{ fontSize: '11px', padding: '3px 10px', border: 'none', cursor: 'pointer', background: p.inStock ? 'rgba(30,107,94,0.15)' : 'rgba(150,0,0,0.1)', color: p.inStock ? '#1E6B5E' : '#960000' }}>
                    {p.inStock ? 'В наличии' : 'Нет'}
                  </button>
                </td>
                <td style={{ padding: '10px 12px' }}>
                  <button onClick={() => deleteProduct(p.id)}><Trash2 size={14} color="rgba(26,26,26,0.4)" /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {data?.pagination && (
        <div className="flex items-center justify-center gap-3 mt-6">
          <button disabled={page === 1} onClick={() => setPage(p => p - 1)} className="btn-primary" style={{ fontSize: '11px', opacity: page === 1 ? 0.4 : 1 }}>← Назад</button>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '13px' }}>{page} / {data.pagination.pages}</span>
          <button disabled={page === data.pagination.pages} onClick={() => setPage(p => p + 1)} className="btn-primary" style={{ fontSize: '11px', opacity: page === data.pagination.pages ? 0.4 : 1 }}>Вперёд →</button>
        </div>
      )}

      {showCreate && <CreateProductModal onClose={() => setShowCreate(false)} onCreated={() => { setShowCreate(false); qc.invalidateQueries({ queryKey: ['admin-products'] }) }} />}
    </div>
  )
}

function CreateProductModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const { data: brands } = useQuery({ queryKey: ['brands-list'], queryFn: () => fetch('/api/brands').then(r => r.json()) })
  const { data: categories } = useQuery({ queryKey: ['categories-list'], queryFn: () => fetch('/api/categories').then(r => r.json()) })

  const [form, setForm] = useState({ name: '', brandId: '', categoryId: '', price: '', description: '' })
  const [saving, setSaving] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    try {
      const slug = form.name.toLowerCase().replace(/[^a-zа-я0-9]+/gi, '-') + '-' + Date.now()
      await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, slug, images: [], volume: [50, 100], topNotes: [], heartNotes: [], baseNotes: [], moods: [], season: [], occasions: [] }),
      })
      toast.success('Товар создан')
      onCreated()
    } catch {
      toast.error('Ошибка создания товара')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-6" style={{ background: 'rgba(0,0,0,0.5)' }}>
      <div className="w-full max-w-lg p-8" style={{ background: 'white' }}>
        <div className="flex items-center justify-between mb-6">
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '24px', color: '#1E6B5E' }}>Новый товар</h2>
          <button onClick={onClose}><X size={20} color="#999" /></button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input required placeholder="Название" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="input-luxury" />
          <select required value={form.brandId} onChange={e => setForm({ ...form, brandId: e.target.value })} className="input-luxury">
            <option value="">Выберите бренд</option>
            {brands?.map((b: any) => <option key={b.id} value={b.id}>{b.name}</option>)}
          </select>
          <select required value={form.categoryId} onChange={e => setForm({ ...form, categoryId: e.target.value })} className="input-luxury">
            <option value="">Выберите категорию</option>
            {categories?.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <input required type="number" placeholder="Цена" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} className="input-luxury" />
          <textarea placeholder="Описание" rows={3} value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} className="input-luxury" />
          <button type="submit" disabled={saving} className="btn-primary w-full">{saving ? 'Сохранение...' : 'Создать товар'}</button>
        </form>
      </div>
    </div>
  )
}
