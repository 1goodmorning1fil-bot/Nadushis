'use client'

import { useQuery } from '@tanstack/react-query'
import { formatPrice } from '@/lib/utils'
import { Package, ShoppingCart, TrendingUp, Users } from 'lucide-react'

export default function AdminDashboard() {
  const { data: stats } = useQuery({
    queryKey: ['admin-stats'],
    queryFn: () => fetch('/api/admin/stats').then(r => r.json()),
  })

  const cards = [
    { label: 'Товаров в каталоге', value: stats?.productCount?.toLocaleString('ru') ?? '—', icon: Package, color: '#1E6B5E' },
    { label: 'Заказов всего', value: stats?.orderCount ?? '—', icon: ShoppingCart, color: '#C9A96E' },
    { label: 'Выручка', value: stats?.revenue ? formatPrice(stats.revenue) : '—', icon: TrendingUp, color: '#1E6B5E' },
    { label: 'Брендов', value: stats?.brandCount ?? '—', icon: Users, color: '#C9A96E' },
  ]

  return (
    <div>
      <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '36px', color: '#1E6B5E', marginBottom: '8px' }}>
        Обзор магазина
      </h1>
      <p style={{ fontFamily: 'var(--font-body)', fontSize: '14px', color: 'rgba(26,26,26,0.5)', marginBottom: '32px' }}>
        Сводная статистика по магазину «На Душись»
      </p>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-5 mb-10">
        {cards.map(card => {
          const Icon = card.icon
          return (
            <div key={card.label} className="p-6" style={{ background: 'white', border: '1px solid rgba(201,169,110,0.2)' }}>
              <Icon size={20} color={card.color} style={{ marginBottom: '16px' }} />
              <div style={{ fontFamily: 'var(--font-display)', fontSize: '28px', fontWeight: 600, color: '#1A1A1A' }}>{card.value}</div>
              <div style={{ fontFamily: 'var(--font-body)', fontSize: '12px', color: 'rgba(26,26,26,0.5)', marginTop: '4px' }}>{card.label}</div>
            </div>
          )
        })}
      </div>

      <div className="p-6" style={{ background: 'white', border: '1px solid rgba(201,169,110,0.2)' }}>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '22px', color: '#1E6B5E', marginBottom: '16px' }}>Недавние заказы</h2>
        {stats?.recentOrders?.length > 0 ? (
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: '1px solid rgba(201,169,110,0.2)' }}>
                {['ID', 'Клиент', 'Сумма', 'Статус', 'Дата'].map(h => (
                  <th key={h} style={{ textAlign: 'left', padding: '8px', fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.1em', textTransform: 'uppercase', color: '#C9A96E' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {stats.recentOrders.map((o: any) => (
                <tr key={o.id} style={{ borderBottom: '1px solid rgba(201,169,110,0.1)' }}>
                  <td style={{ padding: '12px 8px', fontFamily: 'var(--font-mono)', fontSize: '12px' }}>{o.id.slice(0, 8)}</td>
                  <td style={{ padding: '12px 8px', fontFamily: 'var(--font-body)', fontSize: '13px' }}>{o.firstName} {o.lastName}</td>
                  <td style={{ padding: '12px 8px', fontFamily: 'var(--font-display)', fontSize: '14px', color: '#1E6B5E' }}>{formatPrice(o.total)}</td>
                  <td style={{ padding: '12px 8px', fontFamily: 'var(--font-body)', fontSize: '12px' }}>{o.status}</td>
                  <td style={{ padding: '12px 8px', fontFamily: 'var(--font-mono)', fontSize: '12px', color: 'rgba(26,26,26,0.5)' }}>{new Date(o.createdAt).toLocaleDateString('ru')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: 'rgba(26,26,26,0.4)' }}>Нет заказов</p>
        )}
      </div>
    </div>
  )
}
