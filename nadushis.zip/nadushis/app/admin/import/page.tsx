'use client'

import { useState, useCallback } from 'react'
import { useDropzone } from 'react-dropzone'
import toast from 'react-hot-toast'
import { Upload, FileText, CheckCircle, AlertCircle } from 'lucide-react'

export default function AdminImportPage() {
  const [file, setFile] = useState<File | null>(null)
  const [uploading, setUploading] = useState(false)
  const [result, setResult] = useState<any>(null)

  const onDrop = useCallback((files: File[]) => {
    if (files[0]) { setFile(files[0]); setResult(null) }
  }, [])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'text/csv': ['.csv'], 'application/json': ['.json'] },
    maxFiles: 1,
  })

  const handleUpload = async () => {
    if (!file) return
    setUploading(true)
    const formData = new FormData()
    formData.append('file', file)

    try {
      const res = await fetch('/api/upload', { method: 'POST', body: formData })
      const data = await res.json()
      setResult(data)
      toast.success(`Импортировано: ${data.created} товаров`)
    } catch {
      toast.error('Ошибка импорта')
    } finally {
      setUploading(false)
    }
  }

  return (
    <div className="max-w-3xl">
      <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '36px', color: '#1E6B5E', marginBottom: '8px' }}>
        Импорт товаров
      </h1>
      <p style={{ fontFamily: 'var(--font-body)', fontSize: '14px', color: 'rgba(26,26,26,0.5)', marginBottom: '32px' }}>
        Загрузите CSV или JSON файл для массового добавления товаров
      </p>

      <div {...getRootProps()}
        className="p-12 text-center cursor-pointer transition-all"
        style={{ border: `2px dashed ${isDragActive ? '#1E6B5E' : 'rgba(201,169,110,0.4)'}`, background: isDragActive ? 'rgba(30,107,94,0.05)' : 'white' }}
      >
        <input {...getInputProps()} />
        <Upload size={40} color="#C9A96E" style={{ margin: '0 auto 16px' }} />
        {file ? (
          <div>
            <FileText size={20} color="#1E6B5E" style={{ display: 'inline', marginRight: '8px' }} />
            <span style={{ fontFamily: 'var(--font-body)', fontSize: '14px', color: '#1A1A1A' }}>{file.name}</span>
          </div>
        ) : (
          <p style={{ fontFamily: 'var(--font-body)', fontSize: '15px', color: 'rgba(26,26,26,0.6)' }}>
            Перетащите файл сюда или нажмите для выбора<br />
            <span style={{ fontSize: '12px', color: '#C9A96E' }}>Поддерживаются .csv и .json</span>
          </p>
        )}
      </div>

      {file && (
        <button onClick={handleUpload} disabled={uploading} className="btn-primary w-full mt-6">
          {uploading ? 'Загружаем...' : 'Импортировать товары'}
        </button>
      )}

      {result && (
        <div className="mt-8 p-6" style={{ background: 'white', border: '1px solid rgba(201,169,110,0.2)' }}>
          <div className="flex items-center gap-3 mb-4">
            <CheckCircle size={20} color="#1E6B5E" />
            <span style={{ fontFamily: 'var(--font-display)', fontSize: '20px', color: '#1E6B5E' }}>
              Создано: {result.created} · Пропущено: {result.skipped}
            </span>
          </div>
          {result.errors?.length > 0 && (
            <div className="mt-4">
              <div className="flex items-center gap-2 mb-2">
                <AlertCircle size={14} color="#C9A96E" />
                <span style={{ fontFamily: 'var(--font-body)', fontSize: '12px', color: '#C9A96E' }}>Ошибки:</span>
              </div>
              <div className="max-h-48 overflow-y-auto space-y-1">
                {result.errors.map((e: string, i: number) => (
                  <p key={i} style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: 'rgba(26,26,26,0.5)' }}>{e}</p>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Format guide */}
      <div className="mt-12 p-6" style={{ background: 'rgba(30,107,94,0.05)', border: '1px solid rgba(30,107,94,0.15)' }}>
        <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '18px', color: '#1E6B5E', marginBottom: '12px' }}>Формат CSV</h3>
        <pre style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: 'rgba(26,26,26,0.65)', overflow: 'auto', whiteSpace: 'pre' }}>
{`name,brand,category,price,description,images,volume,gender,topNotes,heartNotes,baseNotes
Золотой Рассвет,Tom Ford,Восточные,15000,Описание...,url1|url2,50|100,UNISEX,Бергамот|Лимон,Роза|Жасмин,Ваниль|Мускус`}
        </pre>
        <p style={{ fontFamily: 'var(--font-body)', fontSize: '12px', color: 'rgba(26,26,26,0.5)', marginTop: '12px' }}>
          Множественные значения разделяются символом <code style={{ background: 'rgba(201,169,110,0.15)', padding: '1px 4px' }}>|</code>. Бренд и категория должны существовать в системе.
        </p>
      </div>
    </div>
  )
}
