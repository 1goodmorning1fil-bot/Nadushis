'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { useSession, signOut } from 'next-auth/react'
import { useEffect } from 'react'
import { LayoutDashboard, Package, ShoppingCart, Upload, LogOut } from 'lucide-react'

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const { data: session, status } = useSession()
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    if (status === 'authenticated' && (session?.user as any)?.role !== 'ADMIN') {
      router.push('/shop')
    }
    if (status === 'unauthenticated') {
      router.push('/login?callbackUrl=/admin')
    }
  }, [status, session, router])

  if (status === 'loading') return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: '#F5EDDC' }}>
      <span style={{ fontFamily: 'var(--font-display)', fontSize: '24px', color: '#1E6B5E' }}>Загрузка...</span>
    </div>
  )

  if (status !== 'authenticated' || (session?.user as any)?.role !== 'ADMIN') return null

  const nav = [
    { label: 'Обзор', href: '/admin', icon: LayoutDashboard },
    { label: 'Товары', href: '/admin/products', icon: Package },
    { label: 'Заказы', href: '/admin/orders', icon: ShoppingCart },
    { label: 'Импорт CSV/JSON', href: '/admin/import', icon: Upload },
  ]

  return (
    <div className="flex min-h-screen" style={{ background: '#F5EDDC' }}>
      {/* Sidebar */}
      <aside style={{ width: '260px', background: '#134940', flexShrink: 0 }}>
        <div className="p-6 border-b" style={{ borderColor: 'rgba(201,169,110,0.2)' }}>
          <span style={{ fontFamily: 'var(--font-display)', fontSize: '24px', color: '#F5EDDC' }}>На Душись</span>
          <div style={{ fontFamily: 'var(--font-body)', fontSize: '10px', letterSpacing: '0.2em', textTransform: 'uppercase', color: '#C9A96E', marginTop: '4px' }}>
            Админ-панель
          </div>
        </div>

        <nav className="p-4 space-y-1">
          {nav.map(item => {
            const Icon = item.icon
            const active = pathname === item.href
            return (
              <Link key={item.href} href={item.href}
                className="flex items-center gap-3 px-4 py-3 transition-colors"
                style={{ background: active ? 'rgba(201,169,110,0.15)' : 'transparent', borderLeft: `2px solid ${active ? '#C9A96E' : 'transparent'}` }}
              >
                <Icon size={16} color={active ? '#C9A96E' : 'rgba(245,237,220,0.6)'} />
                <span style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: active ? '#F5EDDC' : 'rgba(245,237,220,0.6)' }}>{item.label}</span>
              </Link>
            )
          })}
        </nav>

        <div className="absolute bottom-0 w-full p-4" style={{ width: '260px' }}>
          <button onClick={() => signOut({ callbackUrl: '/shop' })} className="flex items-center gap-3 px-4 py-3 w-full" style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
            <LogOut size={16} color="rgba(245,237,220,0.6)" />
            <span style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: 'rgba(245,237,220,0.6)' }}>Выйти</span>
          </button>
        </div>
      </aside>

      {/* Content */}
      <main className="flex-1 p-8 overflow-y-auto">{children}</main>
    </div>
  )
}
