'use client'

import { useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { formatPrice } from '@/lib/utils'
import toast from 'react-hot-toast'

const STATUSES = ['PENDING', 'CONFIRMED', 'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED']
const STATUS_LABELS: Record<string, string> = {
  PENDING: 'Ожидает', CONFIRMED: 'Подтверждён', PROCESSING: 'В обработке',
  SHIPPED: 'Отправлен', DELIVERED: 'Доставлен', CANCELLED: 'Отменён',
}

export default function AdminOrdersPage() {
  const qc = useQueryClient()
  const [page, setPage] = useState(1)

  const { data, isLoading } = useQuery({
    queryKey: ['admin-orders', page],
    queryFn: () => fetch(`/api/orders?page=${page}&limit=20`).then(r => r.json()),
  })

  const updateStatus = async (id: string, status: string) => {
    await fetch(`/api/orders/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    })
    toast.success('Статус обновлён')
    qc.invalidateQueries({ queryKey: ['admin-orders'] })
  }

  return (
    <div>
      <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '36px', color: '#1E6B5E', marginBottom: '8px' }}>Заказы</h1>
      <p style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: 'rgba(26,26,26,0.5)', marginBottom: '32px' }}>
        {data?.total ?? '—'} заказов всего
      </p>

      {isLoading ? (
        <p style={{ fontFamily: 'var(--font-body)', color: 'rgba(26,26,26,0.4)' }}>Загрузка...</p>
      ) : (
        <div className="space-y-4">
          {data?.orders?.map((order: any) => (
            <div key={order.id} className="p-6" style={{ background: 'white', border: '1px solid rgba(201,169,110,0.2)' }}>
              <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
                <div>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '13px', color: '#C9A96E' }}>#{order.id.slice(0, 8)}</span>
                  <span style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: 'rgba(26,26,26,0.5)', marginLeft: '12px' }}>
                    {new Date(order.createdAt).toLocaleDateString('ru', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                <select value={order.status} onChange={e => updateStatus(order.id, e.target.value)} className="input-luxury" style={{ width: 'auto', padding: '6px 12px', fontSize: '12px' }}>
                  {STATUSES.map(s => <option key={s} value={s}>{STATUS_LABELS[s]}</option>)}
                </select>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <div style={{ fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.1em', textTransform: 'uppercase', color: '#C9A96E', marginBottom: '4px' }}>Клиент</div>
                  <div style={{ fontFamily: 'var(--font-body)', fontSize: '14px' }}>{order.firstName} {order.lastName}</div>
                  <div style={{ fontFamily: 'var(--font-body)', fontSize: '12px', color: 'rgba(26,26,26,0.5)' }}>{order.email} · {order.phone}</div>
                </div>
                <div>
                  <div style={{ fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.1em', textTransform: 'uppercase', color: '#C9A96E', marginBottom: '4px' }}>Адрес</div>
                  <div style={{ fontFamily: 'var(--font-body)', fontSize: '13px' }}>{order.address}, {order.city}, {order.zip}</div>
                </div>
                <div>
                  <div style={{ fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.1em', textTransform: 'uppercase', color: '#C9A96E', marginBottom: '4px' }}>Сумма</div>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: '20px', fontWeight: 600, color: '#1E6B5E' }}>{formatPrice(order.total)}</div>
                </div>
              </div>

              <div className="mt-4 pt-4" style={{ borderTop: '1px solid rgba(201,169,110,0.1)' }}>
                {order.items.map((item: any) => (
                  <div key={item.id} className="flex justify-between" style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: 'rgba(26,26,26,0.7)', padding: '2px 0' }}>
                    <span>{item.name} ({item.volume}мл × {item.qty})</span>
                    <span>{formatPrice(item.price * item.qty)}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {data?.pages > 1 && (
        <div className="flex items-center justify-center gap-3 mt-8">
          <button disabled={page === 1} onClick={() => setPage(p => p - 1)} className="btn-primary" style={{ fontSize: '11px', opacity: page === 1 ? 0.4 : 1 }}>← Назад</button>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '13px' }}>{page} / {data.pages}</span>
          <button disabled={page === data.pages} onClick={() => setPage(p => p + 1)} className="btn-primary" style={{ fontSize: '11px', opacity: page === data.pages ? 0.4 : 1 }}>Вперёд →</button>
        </div>
      )}
    </div>
  )
}
