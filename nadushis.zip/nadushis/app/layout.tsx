import type { Metadata } from 'next'
import { Cormorant_Garamond, Inter, DM_Mono } from 'next/font/google'
import '@/styles/globals.css'
import { Toaster } from 'react-hot-toast'
import { Providers } from './providers'

const cormorant = Cormorant_Garamond({
  subsets: ['latin', 'cyrillic'],
  weight: ['300', '400', '500', '600', '700'],
  style: ['normal', 'italic'],
  variable: '--font-cormorant',
})

const inter = Inter({
  subsets: ['latin', 'cyrillic'],
  weight: ['300', '400', '500', '600'],
  variable: '--font-inter',
})

const dmMono = DM_Mono({
  subsets: ['latin'],
  weight: ['400', '500'],
  variable: '--font-dm-mono',
})

export const metadata: Metadata = {
  title: {
    default: 'На Душись — Парфюмерный Дом',
    template: '%s | На Душись',
  },
  description: 'Премиальная нишевая парфюмерия. Более 4000 ароматов мировых брендов. Доставка по России.',
  keywords: ['парфюмерия', 'нишевые ароматы', 'духи', 'туалетная вода', 'парфюм'],
  openGraph: {
    title: 'На Душись — Парфюмерный Дом',
    description: 'Премиальная нишевая парфюмерия',
    locale: 'ru_RU',
    type: 'website',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru" className={`${cormorant.variable} ${inter.variable} ${dmMono.variable}`}>
      <body>
        <Providers>
          {children}
          <Toaster
            position="bottom-right"
            toastOptions={{
              style: {
                background: '#1E6B5E',
                color: '#F5EDDC',
                fontFamily: 'var(--font-body)',
                fontSize: '14px',
                borderRadius: '0',
              },
            }}
          />
        </Providers>
      </body>
    </html>
  )
}
