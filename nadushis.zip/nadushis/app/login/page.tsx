'use client'

import { useState } from 'react'
import { signIn } from 'next-auth/react'
import { useRouter, useSearchParams } from 'next/navigation'
import toast from 'react-hot-toast'

export default function LoginPage() {
  const router = useRouter()
  const params = useSearchParams()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    const res = await signIn('credentials', { email, password, redirect: false })
    setLoading(false)

    if (res?.error) {
      toast.error('Неверный email или пароль')
    } else {
      router.push(params.get('callbackUrl') ?? '/admin')
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-6" style={{ background: '#F5EDDC' }}>
      <div className="w-full max-w-sm p-10" style={{ background: 'white', border: '1px solid rgba(201,169,110,0.3)' }}>
        <div className="text-center mb-8">
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '32px', color: '#1E6B5E' }}>На Душись</h1>
          <p style={{ fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.2em', textTransform: 'uppercase', color: '#C9A96E', marginTop: '4px' }}>
            Вход в админ-панель
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <input required type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} className="input-luxury" />
          <input required type="password" placeholder="Пароль" value={password} onChange={e => setPassword(e.target.value)} className="input-luxury" />
          <button type="submit" disabled={loading} className="btn-primary w-full">
            {loading ? 'Вход...' : 'Войти'}
          </button>
        </form>
      </div>
    </div>
  )
}
