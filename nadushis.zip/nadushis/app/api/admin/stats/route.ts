import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

export async function GET() {
  const [productCount, orderCount, brandCount, revenueAgg, recentOrders] = await Promise.all([
    prisma.product.count(),
    prisma.order.count(),
    prisma.brand.count(),
    prisma.order.aggregate({ _sum: { total: true } }),
    prisma.order.findMany({ orderBy: { createdAt: 'desc' }, take: 8 }),
  ])

  return NextResponse.json({
    productCount,
    orderCount,
    brandCount,
    revenue: revenueAgg._sum.total ?? 0,
    recentOrders,
  })
}
