import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { parse } from 'csv-parse/sync'
import { requireAdmin } from '@/lib/guard'

export async function POST(req: NextRequest) {
  const denied = await requireAdmin()
  if (denied) return denied

  const formData = await req.formData()
  const file = formData.get('file') as File

  if (!file) return NextResponse.json({ error: 'No file' }, { status: 400 })

  const text = await file.text()
  const ext = file.name.split('.').pop()?.toLowerCase()

  let records: any[] = []

  if (ext === 'csv') {
    records = parse(text, { columns: true, skip_empty_lines: true, trim: true })
  } else if (ext === 'json') {
    records = JSON.parse(text)
  } else {
    return NextResponse.json({ error: 'Only CSV or JSON supported' }, { status: 400 })
  }

  const results = { created: 0, skipped: 0, errors: [] as string[] }

  for (const row of records) {
    try {
      const brand = await prisma.brand.findFirst({ where: { name: { equals: row.brand, mode: 'insensitive' } } })
      const category = await prisma.category.findFirst({ where: { name: { equals: row.category, mode: 'insensitive' } } })

      if (!brand || !category) {
        results.errors.push(`Skipped "${row.name}": brand or category not found`)
        results.skipped++
        continue
      }

      await prisma.product.upsert({
        where: { slug: row.slug ?? row.name.toLowerCase().replace(/\s+/g, '-') },
        update: { price: parseFloat(row.price) },
        create: {
          name: row.name,
          slug: row.slug ?? row.name.toLowerCase().replace(/\s+/g, '-'),
          brandId: brand.id,
          categoryId: category.id,
          price: parseFloat(row.price),
          comparePrice: row.comparePrice ? parseFloat(row.comparePrice) : null,
          description: row.description ?? '',
          images: row.images ? row.images.split('|') : [],
          volume: row.volume ? row.volume.split('|').map(Number) : [50, 100],
          gender: row.gender ?? 'UNISEX',
          concentration: row.concentration ?? 'EAU_DE_PARFUM',
          topNotes: row.topNotes ? row.topNotes.split('|') : [],
          heartNotes: row.heartNotes ? row.heartNotes.split('|') : [],
          baseNotes: row.baseNotes ? row.baseNotes.split('|') : [],
          moods: row.moods ? row.moods.split('|') : [],
          season: row.season ? row.season.split('|') : [],
          occasions: row.occasions ? row.occasions.split('|') : [],
        },
      })
      results.created++
    } catch (e: any) {
      results.errors.push(e.message)
      results.skipped++
    }
  }

  return NextResponse.json(results)
}
