import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import slugify from 'slugify'

export async function GET() {
  const brands = await prisma.brand.findMany({
    include: { _count: { select: { products: true } } },
    orderBy: { name: 'asc' },
  })
  return NextResponse.json(brands)
}

export async function POST(req: NextRequest) {
  const data = await req.json()
  const slug = slugify(data.name, { lower: true, strict: true })

  const brand = await prisma.brand.create({
    data: { ...data, slug },
  })

  return NextResponse.json(brand, { status: 201 })
}
