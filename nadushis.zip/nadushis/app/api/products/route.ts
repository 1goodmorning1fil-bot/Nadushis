import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { Prisma } from '@prisma/client'
import { requireAdmin } from '@/lib/guard'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)

  const page = parseInt(searchParams.get('page') ?? '1')
  const limit = parseInt(searchParams.get('limit') ?? '24')
  const search = searchParams.get('search') ?? ''
  const brand = searchParams.get('brand') ?? ''
  const category = searchParams.get('category') ?? ''
  const gender = searchParams.get('gender') ?? ''
  const minPrice = parseFloat(searchParams.get('minPrice') ?? '0')
  const maxPrice = parseFloat(searchParams.get('maxPrice') ?? '1000000')
  const sortBy = searchParams.get('sort') ?? 'createdAt'
  const sortOrder = (searchParams.get('order') ?? 'desc') as 'asc' | 'desc'
  const featured = searchParams.get('featured') === 'true'
  const newArrivals = searchParams.get('new') === 'true'
  const bestsellers = searchParams.get('bestseller') === 'true'
  const moods = searchParams.get('moods')?.split(',').filter(Boolean) ?? []
  const notes = searchParams.get('notes')?.split(',').filter(Boolean) ?? []

  const where: Prisma.ProductWhereInput = {
    AND: [
      search ? {
        OR: [
          { name: { contains: search, mode: 'insensitive' } },
          { description: { contains: search, mode: 'insensitive' } },
          { brand: { name: { contains: search, mode: 'insensitive' } } },
        ]
      } : {},
      brand ? { brand: { slug: brand } } : {},
      category ? { category: { slug: category } } : {},
      gender ? { gender: gender as any } : {},
      { price: { gte: minPrice, lte: maxPrice } },
      featured ? { featured: true } : {},
      newArrivals ? { newArrival: true } : {},
      bestsellers ? { bestseller: true } : {},
      moods.length ? { moods: { hasSome: moods } } : {},
      notes.length ? {
        OR: [
          { topNotes: { hasSome: notes } },
          { heartNotes: { hasSome: notes } },
          { baseNotes: { hasSome: notes } },
        ]
      } : {},
    ],
  }

  const [products, total] = await Promise.all([
    prisma.product.findMany({
      where,
      include: { brand: { select: { name: true, slug: true } }, category: { select: { name: true, slug: true } } },
      orderBy: { [sortBy]: sortOrder },
      skip: (page - 1) * limit,
      take: limit,
    }),
    prisma.product.count({ where }),
  ])

  return NextResponse.json({
    products,
    pagination: {
      page,
      limit,
      total,
      pages: Math.ceil(total / limit),
    },
  })
}

export async function POST(req: NextRequest) {
  const denied = await requireAdmin()
  if (denied) return denied

  const data = await req.json()

  const product = await prisma.product.create({
    data: {
      ...data,
      price: parseFloat(data.price),
      comparePrice: data.comparePrice ? parseFloat(data.comparePrice) : null,
    },
    include: { brand: true, category: true },
  })

  return NextResponse.json(product, { status: 201 })
}
