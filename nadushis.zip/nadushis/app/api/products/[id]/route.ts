import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAdmin } from '@/lib/guard'

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const product = await prisma.product.findUnique({
    where: { slug: params.id },
    include: {
      brand: true,
      category: true,
      reviews: { orderBy: { createdAt: 'desc' }, take: 20 },
    },
  })

  if (!product) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  return NextResponse.json(product)
}

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const denied = await requireAdmin()
  if (denied) return denied

  const data = await req.json()

  const product = await prisma.product.update({
    where: { id: params.id },
    data: {
      ...data,
      price: data.price ? parseFloat(data.price) : undefined,
      comparePrice: data.comparePrice ? parseFloat(data.comparePrice) : null,
      updatedAt: new Date(),
    },
    include: { brand: true, category: true },
  })

  return NextResponse.json(product)
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const denied = await requireAdmin()
  if (denied) return denied

  await prisma.product.delete({ where: { id: params.id } })
  return NextResponse.json({ success: true })
}
