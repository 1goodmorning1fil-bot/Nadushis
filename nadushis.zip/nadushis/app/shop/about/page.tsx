'use client'

import { useState } from 'react'
import toast from 'react-hot-toast'

export default function AboutPage() {
  const [form, setForm] = useState({ name: '', email: '', message: '' })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    toast.success('Сообщение отправлено! Мы свяжемся с вами в ближайшее время.')
    setForm({ name: '', email: '', message: '' })
  }

  return (
    <div>
      {/* Hero */}
      <section className="relative" style={{ background: 'linear-gradient(135deg, #134940, #1E6B5E)', padding: '100px 24px' }}>
        <div className="max-w-3xl mx-auto text-center">
          <span style={{ fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.25em', textTransform: 'uppercase', color: 'rgba(201,169,110,0.9)' }}>
            История дома
          </span>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(36px, 6vw, 72px)', fontWeight: 300, color: '#F5EDDC', marginTop: '12px', lineHeight: 1.1 }}>
            О парфюмерном<br /><em>доме «На Душись»</em>
          </h1>
        </div>
      </section>

      {/* Story */}
      <section className="max-w-3xl mx-auto px-6 py-20">
        <p style={{ fontFamily: 'var(--font-display)', fontSize: '22px', fontStyle: 'italic', color: '#1E6B5E', lineHeight: 1.7, textAlign: 'center', marginBottom: '40px' }}>
          «Аромат — это невидимая подпись, которая остаётся в памяти задолго после того, как вы покинули комнату»
        </p>
        <div className="space-y-6" style={{ fontFamily: 'var(--font-body)', fontSize: '15px', color: 'rgba(26,26,26,0.75)', lineHeight: '1.9' }}>
          <p>
            Парфюмерный дом «На Душись» был основан с одной простой идеей: собрать в одном месте лучшие нишевые ароматы мира и сделать их доступными для истинных ценителей парфюмерного искусства.
          </p>
          <p>
            Сегодня наша коллекция включает более 4 000 ароматов от ведущих парфюмерных домов — от классических французских мезонов до молодых независимых брендов, создающих смелые и неожиданные композиции.
          </p>
          <p>
            Каждый флакон в нашем каталоге отобран с особой тщательностью. Мы работаем напрямую с официальными дистрибьюторами, гарантируя 100% оригинальность продукции.
          </p>
        </div>
      </section>

      {/* Values */}
      <section style={{ background: '#F5EDDC', borderTop: '1px solid rgba(201,169,110,0.2)', padding: '80px 24px' }}>
        <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-10 text-center">
          {[
            ['✓', 'Оригинальность', 'Только официальная продукция от авторизованных дистрибьюторов'],
            ['🎨', 'Кураторство', 'Каждый аромат отбирается экспертами для нашей коллекции'],
            ['💎', 'Сервис', 'Персональные консультации и подбор аромата под ваш стиль'],
          ].map(([icon, title, desc]) => (
            <div key={title}>
              <div style={{ fontSize: '32px', marginBottom: '16px' }}>{icon}</div>
              <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '22px', color: '#1E6B5E', marginBottom: '12px' }}>{title}</h3>
              <p style={{ fontFamily: 'var(--font-body)', fontSize: '14px', color: 'rgba(26,26,26,0.6)', lineHeight: '1.7' }}>{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Contact */}
      <section className="max-w-5xl mx-auto px-6 py-20 grid grid-cols-1 md:grid-cols-2 gap-16">
        <div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '40px', fontWeight: 400, color: '#1E6B5E', marginBottom: '24px' }}>
            Контакты
          </h2>
          <div className="space-y-5" style={{ fontFamily: 'var(--font-body)', fontSize: '15px', color: 'rgba(26,26,26,0.75)' }}>
            <div>
              <div style={{ fontSize: '11px', letterSpacing: '0.15em', textTransform: 'uppercase', color: '#C9A96E', marginBottom: '4px' }}>Адрес</div>
              Москва, ул. Кузнецкий Мост, 3
            </div>
            <div>
              <div style={{ fontSize: '11px', letterSpacing: '0.15em', textTransform: 'uppercase', color: '#C9A96E', marginBottom: '4px' }}>Телефон</div>
              +7 (495) 123-45-67
            </div>
            <div>
              <div style={{ fontSize: '11px', letterSpacing: '0.15em', textTransform: 'uppercase', color: '#C9A96E', marginBottom: '4px' }}>Email</div>
              info@nadushis.ru
            </div>
            <div>
              <div style={{ fontSize: '11px', letterSpacing: '0.15em', textTransform: 'uppercase', color: '#C9A96E', marginBottom: '4px' }}>Время работы</div>
              Пн–Вс: 10:00–21:00
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <input required placeholder="Ваше имя" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="input-luxury" />
          <input required type="email" placeholder="Email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} className="input-luxury" />
          <textarea required placeholder="Сообщение" rows={5} value={form.message} onChange={e => setForm({ ...form, message: e.target.value })} className="input-luxury" />
          <button type="submit" className="btn-primary w-full">Отправить сообщение</button>
        </form>
      </section>
    </div>
  )
}
