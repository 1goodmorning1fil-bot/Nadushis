'use client'

import Link from 'next/link'
import { useEffect, useRef, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { ProductCard } from '@/components/shop/ProductCard'
import { ArrowRight, Sparkles } from 'lucide-react'

// ─── Spray Canvas Animation ─────────────────────────────────────────
function SprayCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    canvas.width = canvas.offsetWidth
    canvas.height = canvas.offsetHeight

    const particles: Array<{
      x: number; y: number; vx: number; vy: number;
      life: number; maxLife: number; size: number; hue: number
    }> = []

    let animId: number
    let spraying = false
    let mouseX = canvas.width / 2
    let mouseY = canvas.height / 2

    const spawnParticle = () => {
      const angle = (Math.random() * 80 - 40) * (Math.PI / 180)
      const speed = Math.random() * 3 + 1.5
      particles.push({
        x: mouseX, y: mouseY,
        vx: Math.sin(angle) * speed,
        vy: -Math.cos(angle) * speed - Math.random() * 1.5,
        life: 0,
        maxLife: Math.random() * 60 + 40,
        size: Math.random() * 4 + 1,
        hue: Math.random() * 30 - 15,
      })
    }

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      if (spraying) {
        for (let i = 0; i < 8; i++) spawnParticle()
      }

      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i]
        p.x += p.vx; p.y += p.vy
        p.vy += 0.04; p.vx *= 0.99
        p.life++
        if (p.life > p.maxLife) { particles.splice(i, 1); continue }
        const alpha = 1 - p.life / p.maxLife
        ctx.beginPath()
        ctx.arc(p.x, p.y, p.size * alpha, 0, Math.PI * 2)
        const r = Math.round(201 + p.hue)
        const g = Math.round(169 + p.hue * 0.5)
        const b = Math.round(110 + p.hue)
        ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${alpha * 0.7})`
        ctx.fill()

        // Shimmer dot
        if (p.life % 5 === 0) {
          ctx.beginPath()
          ctx.arc(p.x, p.y, p.size * 0.3 * alpha, 0, Math.PI * 2)
          ctx.fillStyle = `rgba(255, 255, 255, ${alpha * 0.5})`
          ctx.fill()
        }
      }

      animId = requestAnimationFrame(animate)
    }

    // Auto-spray demo
    let autoTimer = setInterval(() => {
      mouseX = canvas.width * (0.3 + Math.random() * 0.4)
      mouseY = canvas.height * (0.3 + Math.random() * 0.4)
      spraying = true
      setTimeout(() => { spraying = false }, 600)
    }, 2000)

    canvas.addEventListener('mousemove', e => {
      const rect = canvas.getBoundingClientRect()
      mouseX = e.clientX - rect.left
      mouseY = e.clientY - rect.top
    })
    canvas.addEventListener('mouseenter', () => { spraying = true; clearInterval(autoTimer) })
    canvas.addEventListener('mouseleave', () => {
      spraying = false
      autoTimer = setInterval(() => {
        mouseX = canvas.width * (0.3 + Math.random() * 0.4)
        mouseY = canvas.height * (0.3 + Math.random() * 0.4)
        spraying = true
        setTimeout(() => { spraying = false }, 600)
      }, 2000)
    })

    animate()
    return () => { cancelAnimationFrame(animId); clearInterval(autoTimer) }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-auto"
      style={{ zIndex: 2 }}
    />
  )
}

// ─── Product Card skeleton ─────────────────────────────────────────
function ProductSkeleton() {
  return (
    <div className="luxury-card">
      <div className="skeleton w-full" style={{ height: '280px' }} />
      <div className="p-4 space-y-2">
        <div className="skeleton h-3 w-1/3 rounded" />
        <div className="skeleton h-5 w-2/3 rounded" />
        <div className="skeleton h-4 w-1/4 rounded" />
      </div>
    </div>
  )
}

// ─── Main Home Page ─────────────────────────────────────────────────
export default function HomePage() {
  const { data: featuredData, isLoading: featuredLoading } = useQuery({
    queryKey: ['featured-products'],
    queryFn: () => fetch('/api/products?featured=true&limit=8').then(r => r.json()),
  })

  const { data: newData, isLoading: newLoading } = useQuery({
    queryKey: ['new-products'],
    queryFn: () => fetch('/api/products?new=true&limit=4').then(r => r.json()),
  })

  const brands = [
    'Creed', 'Tom Ford', 'Byredo', 'Le Labo',
    'Diptyque', 'Amouage', 'Frederic Malle', 'Xerjoff'
  ]

  return (
    <div>
      {/* ── HERO ─────────────────────────────────────── */}
      <section className="relative overflow-hidden" style={{ minHeight: '90vh', background: 'linear-gradient(160deg, #F5EDDC 0%, #EBE0C8 40%, #DFD1B0 100%)' }}>
        <SprayCanvas />

        {/* Decorative circles */}
        <div className="absolute" style={{ width: '600px', height: '600px', borderRadius: '50%', border: '1px solid rgba(201, 169, 110, 0.15)', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', zIndex: 1 }} />
        <div className="absolute" style={{ width: '400px', height: '400px', borderRadius: '50%', border: '1px solid rgba(201, 169, 110, 0.2)', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', zIndex: 1 }} />

        <div className="relative z-10 flex flex-col items-center justify-center text-center px-6" style={{ minHeight: '90vh' }}>
          {/* Eyebrow */}
          <div className="mb-6 flex items-center gap-3">
            <div style={{ width: '40px', height: '1px', background: '#C9A96E' }} />
            <span style={{ fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.3em', textTransform: 'uppercase', color: '#C9A96E' }}>
              Парфюмерный Дом
            </span>
            <div style={{ width: '40px', height: '1px', background: '#C9A96E' }} />
          </div>

          {/* Main headline */}
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(52px, 9vw, 120px)', fontWeight: 300, lineHeight: 0.9, color: '#1E6B5E', letterSpacing: '-0.02em', marginBottom: '8px' }}>
            На Душись
          </h1>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(18px, 3vw, 36px)', fontWeight: 400, fontStyle: 'italic', color: '#C9A96E', marginBottom: '24px', letterSpacing: '0.02em' }}>
            Ароматы, которые остаются
          </h2>

          <p style={{ fontFamily: 'var(--font-body)', fontSize: '15px', color: 'rgba(26,26,26,0.6)', maxWidth: '480px', lineHeight: '1.8', marginBottom: '48px' }}>
            Коллекция из более чем 4&thinsp;000 ароматов от ведущих парфюмерных домов мира. Найдите свой уникальный аромат.
          </p>

          <div className="flex items-center gap-4 flex-wrap justify-center">
            <Link href="/shop/catalog" className="btn-primary flex items-center gap-2" style={{ fontSize: '12px' }}>
              Исследовать коллекцию
              <ArrowRight size={14} />
            </Link>
            <Link href="/shop/brands" className="flex items-center gap-2 group" style={{ fontFamily: 'var(--font-body)', fontSize: '12px', letterSpacing: '0.1em', textTransform: 'uppercase', color: '#1E6B5E' }}>
              <span>Наши бренды</span>
              <span style={{ color: '#C9A96E', transition: 'transform 0.2s' }}>→</span>
            </Link>
          </div>

          {/* Stats */}
          <div className="mt-20 flex items-center gap-12 flex-wrap justify-center">
            {[['4 000+', 'ароматов'], ['200+', 'брендов'], ['15 лет', 'на рынке'], ['98%', 'довольных']].map(([n, l]) => (
              <div key={l} className="text-center">
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '32px', fontWeight: 600, color: '#1E6B5E' }}>{n}</div>
                <div style={{ fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.15em', textTransform: 'uppercase', color: 'rgba(26,26,26,0.5)', marginTop: '4px' }}>{l}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Scroll hint */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 z-10">
          <span style={{ fontFamily: 'var(--font-body)', fontSize: '10px', letterSpacing: '0.2em', textTransform: 'uppercase', color: 'rgba(26,26,26,0.4)' }}>Прокрутите</span>
          <div style={{ width: '1px', height: '40px', background: 'linear-gradient(to bottom, rgba(201, 169, 110, 0.6), transparent)' }} />
        </div>
      </section>

      {/* ── FEATURED PRODUCTS ───────────────────────── */}
      <section className="max-w-7xl mx-auto px-6 py-24">
        <div className="text-center mb-14">
          <span style={{ fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.25em', textTransform: 'uppercase', color: '#C9A96E' }}>Редакторский выбор</span>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(36px, 5vw, 60px)', fontWeight: 400, color: '#1E6B5E', marginTop: '8px' }}>
            Избранные ароматы
          </h2>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {featuredLoading
            ? Array(8).fill(0).map((_, i) => <ProductSkeleton key={i} />)
            : featuredData?.products?.map((p: any) => <ProductCard key={p.id} product={p} />)
          }
        </div>

        <div className="text-center mt-12">
          <Link href="/shop/catalog" className="btn-primary">
            Весь каталог — {featuredData?.pagination?.total?.toLocaleString('ru')} ароматов
          </Link>
        </div>
      </section>

      {/* ── CATEGORY GRID ───────────────────────────── */}
      <section style={{ background: '#1E6B5E', padding: '80px 0' }}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-14">
            <span style={{ fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.25em', textTransform: 'uppercase', color: 'rgba(201, 169, 110, 0.8)' }}>Ольфактивные группы</span>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(36px, 5vw, 60px)', fontWeight: 400, color: '#F5EDDC', marginTop: '8px' }}>
              Найдите свою нишу
            </h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { name: 'Цветочные', icon: '🌸', slug: 'floral', desc: 'Нежность и романтика' },
              { name: 'Восточные', icon: '🌙', slug: 'oriental', desc: 'Тайна и соблазн' },
              { name: 'Древесные', icon: '🌲', slug: 'woody', desc: 'Сила и стабильность' },
              { name: 'Свежие', icon: '💧', slug: 'fresh', desc: 'Чистота и энергия' },
              { name: 'Шипровые', icon: '🍃', slug: 'chypre', desc: 'Элегантность' },
              { name: 'Гурманские', icon: '🍫', slug: 'gourmand', desc: 'Сладкое удовольствие' },
              { name: 'Акватические', icon: '🌊', slug: 'aquatic', desc: 'Морская свобода' },
              { name: 'Фужерные', icon: '🌿', slug: 'fougere', desc: 'Классика жанра' },
            ].map(cat => (
              <Link key={cat.slug} href={`/shop/catalog?category=${cat.slug}`}>
                <div
                  className="p-6 text-center transition-all duration-300 cursor-pointer"
                  style={{ border: '1px solid rgba(201, 169, 110, 0.2)', background: 'rgba(245, 237, 220, 0.04)' }}
                  onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = 'rgba(201, 169, 110, 0.1)'; (e.currentTarget as HTMLElement).style.borderColor = 'rgba(201, 169, 110, 0.5)' }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = 'rgba(245, 237, 220, 0.04)'; (e.currentTarget as HTMLElement).style.borderColor = 'rgba(201, 169, 110, 0.2)' }}
                >
                  <div style={{ fontSize: '32px', marginBottom: '12px' }}>{cat.icon}</div>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: '18px', color: '#F5EDDC', marginBottom: '6px' }}>{cat.name}</div>
                  <div style={{ fontFamily: 'var(--font-body)', fontSize: '12px', color: 'rgba(201, 169, 110, 0.7)' }}>{cat.desc}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── NEW ARRIVALS ─────────────────────────────── */}
      <section className="max-w-7xl mx-auto px-6 py-24">
        <div className="flex items-end justify-between mb-14">
          <div>
            <span style={{ fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.25em', textTransform: 'uppercase', color: '#C9A96E' }}>Только что прибыли</span>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(36px, 5vw, 60px)', fontWeight: 400, color: '#1E6B5E', marginTop: '8px' }}>
              Новинки
            </h2>
          </div>
          <Link href="/shop/catalog?new=true" style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: '#1E6B5E', letterSpacing: '0.1em', textDecoration: 'underline', textUnderlineOffset: '4px' }}>
            Смотреть все
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {newLoading
            ? Array(4).fill(0).map((_, i) => <ProductSkeleton key={i} />)
            : newData?.products?.map((p: any) => <ProductCard key={p.id} product={p} />)
          }
        </div>
      </section>

      {/* ── BRAND STRIP ─────────────────────────────── */}
      <section style={{ background: '#F5EDDC', borderTop: '1px solid rgba(201,169,110,0.2)', borderBottom: '1px solid rgba(201,169,110,0.2)', padding: '40px 0', overflow: 'hidden' }}>
        <div className="ticker-inner">
          {[...brands, ...brands].map((b, i) => (
            <span key={i} style={{ fontFamily: 'var(--font-display)', fontSize: '22px', fontWeight: 300, color: '#1E6B5E', padding: '0 40px', opacity: 0.6, whiteSpace: 'nowrap' }}>
              {b}
            </span>
          ))}
        </div>
      </section>

      {/* ── EDITORIAL BANNER ────────────────────────── */}
      <section className="relative overflow-hidden" style={{ minHeight: '60vh', background: 'linear-gradient(135deg, #134940 0%, #1E6B5E 100%)' }}>
        <div className="absolute inset-0 flex items-center justify-center" style={{ opacity: 0.05 }}>
          <span style={{ fontFamily: 'var(--font-display)', fontSize: '300px', fontWeight: 700, color: '#C9A96E', letterSpacing: '-20px' }}>ND</span>
        </div>
        <div className="relative z-10 flex flex-col items-center justify-center text-center px-6 py-24">
          <Sparkles size={32} color="#C9A96E" style={{ marginBottom: '24px' }} />
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(36px, 6vw, 80px)', fontWeight: 300, color: '#F5EDDC', marginBottom: '16px', lineHeight: 1 }}>
            Консультация<br />
            <em>парфюмера</em>
          </h2>
          <p style={{ fontFamily: 'var(--font-body)', fontSize: '15px', color: 'rgba(245,237,220,0.65)', maxWidth: '400px', lineHeight: 1.8, marginBottom: '40px' }}>
            Наши эксперты помогут подобрать идеальный аромат, учитывая ваши предпочтения и стиль жизни.
          </p>
          <Link href="/shop/about" className="btn-gold" style={{ fontSize: '12px' }}>
            Записаться на консультацию
          </Link>
        </div>
      </section>
    </div>
  )
}
