'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useCart } from '@/lib/store'
import { formatPrice } from '@/lib/utils'
import toast from 'react-hot-toast'
import { Lock } from 'lucide-react'

export default function CheckoutPage() {
  const router = useRouter()
  const { items, total, clear } = useCart()
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    firstName: '', lastName: '', email: '', phone: '',
    address: '', city: '', zip: '', country: 'RU', notes: '',
  })

  const shipping = total() >= 5000 ? 0 : 490
  const grandTotal = total() + shipping

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (items.length === 0) return

    setLoading(true)
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          total: grandTotal,
          shipping,
          items: items.map(i => ({ id: i.id, name: i.name, price: i.price, volume: i.volume, qty: i.qty })),
        }),
      })

      if (!res.ok) throw new Error('Ошибка при оформлении заказа')

      const order = await res.json()
      clear()
      toast.success('Заказ успешно оформлен!')
      router.push(`/shop/checkout/success?order=${order.id}`)
    } catch (err) {
      toast.error('Не удалось оформить заказ. Попробуйте снова.')
    } finally {
      setLoading(false)
    }
  }

  if (items.length === 0) return (
    <div className="text-center py-32">
      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '32px', color: '#1E6B5E' }}>Корзина пуста</h2>
      <a href="/shop/catalog" className="btn-primary inline-block mt-6">В каталог</a>
    </div>
  )

  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(32px, 5vw, 56px)', fontWeight: 400, color: '#1E6B5E', marginBottom: '40px' }}>
        Оформление заказа
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Form */}
        <form onSubmit={handleSubmit} className="lg:col-span-2 space-y-8">
          <div>
            <h3 style={{ fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.2em', textTransform: 'uppercase', color: '#C9A96E', marginBottom: '16px' }}>
              Контактная информация
            </h3>
            <div className="grid grid-cols-2 gap-4">
              <input name="firstName" required placeholder="Имя" value={form.firstName} onChange={handleChange} className="input-luxury" />
              <input name="lastName" required placeholder="Фамилия" value={form.lastName} onChange={handleChange} className="input-luxury" />
              <input name="email" type="email" required placeholder="Email" value={form.email} onChange={handleChange} className="input-luxury" />
              <input name="phone" required placeholder="Телефон" value={form.phone} onChange={handleChange} className="input-luxury" />
            </div>
          </div>

          <div>
            <h3 style={{ fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.2em', textTransform: 'uppercase', color: '#C9A96E', marginBottom: '16px' }}>
              Адрес доставки
            </h3>
            <div className="space-y-4">
              <input name="address" required placeholder="Улица, дом, квартира" value={form.address} onChange={handleChange} className="input-luxury" />
              <div className="grid grid-cols-2 gap-4">
                <input name="city" required placeholder="Город" value={form.city} onChange={handleChange} className="input-luxury" />
                <input name="zip" required placeholder="Индекс" value={form.zip} onChange={handleChange} className="input-luxury" />
              </div>
              <textarea name="notes" placeholder="Комментарий к заказу (необязательно)" value={form.notes} onChange={handleChange} className="input-luxury" rows={3} />
            </div>
          </div>

          <div>
            <h3 style={{ fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.2em', textTransform: 'uppercase', color: '#C9A96E', marginBottom: '16px' }}>
              Оплата
            </h3>
            <div className="p-4 flex items-center gap-3" style={{ border: '1px solid rgba(30,107,94,0.3)', background: 'rgba(30,107,94,0.05)' }}>
              <Lock size={16} color="#1E6B5E" />
              <span style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: 'rgba(26,26,26,0.7)' }}>
                Оплата при получении или картой онлайн после подтверждения заказа
              </span>
            </div>
          </div>

          <button type="submit" disabled={loading} className="btn-primary w-full" style={{ opacity: loading ? 0.6 : 1 }}>
            {loading ? 'Оформляем заказ...' : `Оплатить ${formatPrice(grandTotal)}`}
          </button>
        </form>

        {/* Summary */}
        <div>
          <div className="p-6 sticky top-24" style={{ border: '1px solid rgba(201,169,110,0.3)', background: 'white' }}>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '22px', color: '#1E6B5E', marginBottom: '20px' }}>Ваш заказ</h2>
            <div className="space-y-3 mb-6 max-h-64 overflow-y-auto pr-2">
              {items.map(item => (
                <div key={`${item.id}-${item.volume}`} className="flex justify-between items-start gap-2">
                  <div>
                    <div style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: '#1A1A1A' }}>{item.name}</div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: 'rgba(26,26,26,0.5)' }}>{item.volume}мл × {item.qty}</div>
                  </div>
                  <span style={{ fontFamily: 'var(--font-display)', fontSize: '14px', color: '#1E6B5E', flexShrink: 0 }}>{formatPrice(item.price * item.qty)}</span>
                </div>
              ))}
            </div>
            <div className="pt-4 space-y-2" style={{ borderTop: '1px solid rgba(201,169,110,0.2)' }}>
              <div className="flex justify-between" style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: 'rgba(26,26,26,0.6)' }}>
                <span>Доставка</span><span>{shipping === 0 ? 'Бесплатно' : formatPrice(shipping)}</span>
              </div>
              <div className="flex justify-between pt-2" style={{ fontFamily: 'var(--font-display)', fontSize: '20px', fontWeight: 600, color: '#1E6B5E' }}>
                <span>Итого</span><span>{formatPrice(grandTotal)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
