'use client'

import { useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { CheckCircle } from 'lucide-react'

export default function CheckoutSuccessPage() {
  const params = useSearchParams()
  const orderId = params.get('order')

  return (
    <div className="min-h-screen flex flex-col items-center justify-center text-center px-6" style={{ background: '#F5EDDC' }}>
      <CheckCircle size={64} color="#1E6B5E" style={{ marginBottom: '24px' }} />
      <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(32px, 5vw, 56px)', color: '#1E6B5E', marginBottom: '12px' }}>
        Заказ принят
      </h1>
      <p style={{ fontFamily: 'var(--font-body)', fontSize: '15px', color: 'rgba(26,26,26,0.6)', marginBottom: '8px' }}>
        Спасибо за заказ! Мы отправили подтверждение на вашу почту.
      </p>
      {orderId && (
        <p style={{ fontFamily: 'var(--font-mono)', fontSize: '13px', color: '#C9A96E', marginBottom: '32px' }}>
          Номер заказа: {orderId}
        </p>
      )}
      <Link href="/shop/catalog" className="btn-primary">Продолжить покупки</Link>
    </div>
  )
}
