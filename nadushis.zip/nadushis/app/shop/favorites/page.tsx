'use client'

import { useFavorites, useCart } from '@/lib/store'
import { formatPrice } from '@/lib/utils'
import Image from 'next/image'
import Link from 'next/link'
import { Heart, ShoppingBag } from 'lucide-react'
import toast from 'react-hot-toast'

export default function FavoritesPage() {
  const { items, toggle } = useFavorites()
  const { add } = useCart()

  if (items.length === 0) return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-6">
      <Heart size={64} color="#C9A96E" style={{ marginBottom: '24px', opacity: 0.5 }} />
      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '40px', color: '#1E6B5E', marginBottom: '12px' }}>
        Список избранного пуст
      </h2>
      <p style={{ fontFamily: 'var(--font-body)', fontSize: '15px', color: 'rgba(26,26,26,0.5)', marginBottom: '32px' }}>
        Сохраняйте ароматы, которые вам понравились
      </p>
      <Link href="/shop/catalog" className="btn-primary">Перейти в каталог</Link>
    </div>
  )

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(32px, 5vw, 56px)', fontWeight: 400, color: '#1E6B5E', marginBottom: '12px' }}>
        Избранное
      </h1>
      <p style={{ fontFamily: 'var(--font-body)', fontSize: '14px', color: 'rgba(26,26,26,0.5)', marginBottom: '40px' }}>
        {items.length} {items.length === 1 ? 'аромат' : 'ароматов'}
      </p>

      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-6">
        {items.map(item => (
          <div key={item.id} className="luxury-card">
            <Link href={`/shop/product/${item.slug}`}>
              <div className="relative" style={{ aspectRatio: '3/4', background: '#F5EDDC' }}>
                {item.image ? (
                  <Image src={item.image} alt={item.name} fill className="object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <span style={{ fontFamily: 'var(--font-display)', fontSize: '36px', color: '#C9A96E', opacity: 0.4 }}>ND</span>
                  </div>
                )}
                <button
                  onClick={(e) => { e.preventDefault(); toggle(item) }}
                  className="absolute top-3 right-3 w-8 h-8 flex items-center justify-center"
                  style={{ background: 'rgba(245,237,220,0.9)' }}
                >
                  <Heart size={14} color="#1E6B5E" fill="#1E6B5E" />
                </button>
              </div>
            </Link>
            <div className="p-4">
              <div style={{ fontFamily: 'var(--font-body)', fontSize: '10px', letterSpacing: '0.15em', textTransform: 'uppercase', color: '#C9A96E', marginBottom: '4px' }}>{item.brand}</div>
              <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '16px', color: '#1A1A1A', marginBottom: '10px' }}>{item.name}</h3>
              <div className="flex items-center justify-between">
                <span style={{ fontFamily: 'var(--font-display)', fontSize: '18px', fontWeight: 600, color: '#1E6B5E' }}>{formatPrice(item.price)}</span>
                <button
                  onClick={() => { add({ ...item, volume: 50, qty: 1 }); toast.success('Добавлено в корзину') }}
                  style={{ width: '32px', height: '32px', background: '#1E6B5E', display: 'flex', alignItems: 'center', justifyContent: 'center', border: 'none', cursor: 'pointer' }}
                >
                  <ShoppingBag size={14} color="#F5EDDC" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
