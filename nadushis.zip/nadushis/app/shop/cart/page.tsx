'use client'

import { useCart } from '@/lib/store'
import { formatPrice } from '@/lib/utils'
import Image from 'next/image'
import Link from 'next/link'
import { Trash2, ShoppingBag, ArrowRight } from 'lucide-react'

export default function CartPage() {
  const { items, remove, update, total, clear } = useCart()

  if (items.length === 0) return (
    <div className="min-h-screen flex flex-col items-center justify-center text-center px-6" style={{ background: '#F5EDDC' }}>
      <ShoppingBag size={64} color="#C9A96E" style={{ marginBottom: '24px', opacity: 0.5 }} />
      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '40px', color: '#1E6B5E', marginBottom: '12px' }}>
        Корзина пуста
      </h2>
      <p style={{ fontFamily: 'var(--font-body)', fontSize: '15px', color: 'rgba(26,26,26,0.5)', marginBottom: '32px' }}>
        Добавьте ароматы, которые вас вдохновляют
      </p>
      <Link href="/shop/catalog" className="btn-primary">Перейти в каталог</Link>
    </div>
  )

  const shipping = total() >= 5000 ? 0 : 490

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <div className="flex items-center justify-between mb-10">
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(32px, 5vw, 56px)', fontWeight: 400, color: '#1E6B5E' }}>
          Корзина
        </h1>
        <button onClick={clear} style={{ fontFamily: 'var(--font-body)', fontSize: '12px', color: 'rgba(26,26,26,0.5)', textDecoration: 'underline', background: 'none', border: 'none', cursor: 'pointer' }}>
          Очистить
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Items */}
        <div className="lg:col-span-2 space-y-4">
          {items.map(item => (
            <div key={`${item.id}-${item.volume}`} className="flex gap-5 p-5" style={{ border: '1px solid rgba(201,169,110,0.2)', background: 'white' }}>
              <div className="relative flex-shrink-0" style={{ width: '100px', height: '130px', background: '#F5EDDC' }}>
                {item.image ? <Image src={item.image} alt={item.name} fill className="object-cover" /> : (
                  <div className="w-full h-full flex items-center justify-center">
                    <span style={{ fontFamily: 'var(--font-display)', fontSize: '24px', color: '#C9A96E', opacity: 0.4 }}>ND</span>
                  </div>
                )}
              </div>

              <div className="flex-1 flex flex-col justify-between">
                <div>
                  <div style={{ fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.15em', textTransform: 'uppercase', color: '#C9A96E', marginBottom: '4px' }}>{item.brand}</div>
                  <Link href={`/shop/product/${item.slug}`}>
                    <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '18px', color: '#1A1A1A', marginBottom: '4px' }}>{item.name}</h3>
                  </Link>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '12px', color: 'rgba(26,26,26,0.5)' }}>{item.volume} мл</span>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center border" style={{ borderColor: 'rgba(201,169,110,0.4)' }}>
                    <button onClick={() => item.qty > 1 ? update(item.id, item.volume, item.qty - 1) : remove(item.id, item.volume)}
                      style={{ width: '36px', height: '36px', background: 'none', border: 'none', fontSize: '16px', cursor: 'pointer', color: '#1E6B5E' }}>−</button>
                    <span style={{ width: '36px', textAlign: 'center', fontFamily: 'var(--font-mono)', fontSize: '14px' }}>{item.qty}</span>
                    <button onClick={() => update(item.id, item.volume, item.qty + 1)}
                      style={{ width: '36px', height: '36px', background: 'none', border: 'none', fontSize: '16px', cursor: 'pointer', color: '#1E6B5E' }}>+</button>
                  </div>

                  <div className="flex items-center gap-4">
                    <span style={{ fontFamily: 'var(--font-display)', fontSize: '20px', fontWeight: 600, color: '#1E6B5E' }}>
                      {formatPrice(item.price * item.qty)}
                    </span>
                    <button onClick={() => remove(item.id, item.volume)} className="transition-opacity hover:opacity-60">
                      <Trash2 size={16} color="rgba(26,26,26,0.4)" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Summary */}
        <div>
          <div className="p-6 sticky top-24" style={{ border: '1px solid rgba(201,169,110,0.3)', background: 'white' }}>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '24px', color: '#1E6B5E', marginBottom: '20px' }}>
              Итого
            </h2>

            <div className="space-y-4 mb-6">
              <div className="flex justify-between">
                <span style={{ fontFamily: 'var(--font-body)', fontSize: '14px', color: 'rgba(26,26,26,0.6)' }}>Товары</span>
                <span style={{ fontFamily: 'var(--font-display)', fontSize: '18px', color: '#1A1A1A' }}>{formatPrice(total())}</span>
              </div>
              <div className="flex justify-between">
                <span style={{ fontFamily: 'var(--font-body)', fontSize: '14px', color: 'rgba(26,26,26,0.6)' }}>Доставка</span>
                <span style={{ fontFamily: 'var(--font-display)', fontSize: '18px', color: shipping === 0 ? '#1E6B5E' : '#1A1A1A' }}>
                  {shipping === 0 ? 'Бесплатно' : formatPrice(shipping)}
                </span>
              </div>
              {shipping > 0 && (
                <p style={{ fontFamily: 'var(--font-body)', fontSize: '12px', color: '#C9A96E' }}>
                  До бесплатной доставки: {formatPrice(5000 - total())}
                </p>
              )}
              <div className="pt-4 flex justify-between" style={{ borderTop: '1px solid rgba(201,169,110,0.3)' }}>
                <span style={{ fontFamily: 'var(--font-body)', fontSize: '14px', fontWeight: 600, color: '#1A1A1A' }}>К оплате</span>
                <span style={{ fontFamily: 'var(--font-display)', fontSize: '24px', fontWeight: 600, color: '#1E6B5E' }}>{formatPrice(total() + shipping)}</span>
              </div>
            </div>

            <Link href="/shop/checkout" className="btn-primary w-full flex items-center justify-center gap-2 text-center">
              Оформить заказ <ArrowRight size={16} />
            </Link>

            <Link href="/shop/catalog" className="block text-center mt-4" style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: '#1E6B5E', textDecoration: 'underline', textUnderlineOffset: '3px' }}>
              Продолжить покупки
            </Link>

            {/* Trust badges */}
            <div className="mt-6 pt-6 space-y-2" style={{ borderTop: '1px solid rgba(201,169,110,0.2)' }}>
              {['🔒 Безопасная оплата', '📦 Бережная упаковка', '✓ 100% оригинал'].map(b => (
                <div key={b} style={{ fontFamily: 'var(--font-body)', fontSize: '12px', color: 'rgba(26,26,26,0.55)' }}>{b}</div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
