'use client'

import { useQuery } from '@tanstack/react-query'
import Link from 'next/link'

export default function BrandsPage() {
  const { data, isLoading } = useQuery({
    queryKey: ['brands'],
    queryFn: () => fetch('/api/brands').then(r => r.json()),
  })

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <div className="text-center mb-16">
        <span style={{ fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.25em', textTransform: 'uppercase', color: '#C9A96E' }}>
          Дома, которым мы доверяем
        </span>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(36px, 6vw, 72px)', fontWeight: 400, color: '#1E6B5E', marginTop: '8px' }}>
          Наши бренды
        </h1>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
          {Array(9).fill(0).map((_, i) => <div key={i} className="skeleton" style={{ height: '180px' }} />)}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {data?.map((brand: any) => (
            <Link key={brand.id} href={`/shop/catalog?brand=${brand.slug}`}>
              <div className="luxury-card p-8 h-full flex flex-col justify-between" style={{ minHeight: '220px' }}>
                <div>
                  <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '28px', fontWeight: 500, color: '#1E6B5E', marginBottom: '8px' }}>
                    {brand.name}
                  </h3>
                  <p style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: 'rgba(26,26,26,0.6)', lineHeight: '1.7' }}>
                    {brand.description}
                  </p>
                </div>
                <div className="flex items-center justify-between mt-6">
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: '#C9A96E' }}>
                    {brand.country} · {brand.founded}
                  </span>
                  <span style={{ fontFamily: 'var(--font-body)', fontSize: '12px', color: '#1E6B5E', textDecoration: 'underline', textUnderlineOffset: '3px' }}>
                    {brand._count?.products ?? 0} ароматов
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  )
}
