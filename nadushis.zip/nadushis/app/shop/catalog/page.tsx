'use client'

import { useState, useEffect, useCallback } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import { useQuery } from '@tanstack/react-query'
import { ProductCard } from '@/components/shop/ProductCard'
import { SlidersHorizontal, ChevronDown, X } from 'lucide-react'
import { formatPrice } from '@/lib/utils'

const BRANDS = ['Creed', 'Tom Ford', 'Byredo', 'Le Labo', 'Diptyque', 'Amouage', 'Serge Lutens', 'Frederic Malle', 'Xerjoff', 'Nishane', 'Parfums de Marly', 'Montale', 'Rasasi', 'Bvlgari', 'Initio']
const NOTES = ['Роза', 'Жасмин', 'Уд', 'Сандал', 'Ваниль', 'Мускус', 'Бергамот', 'Пачули', 'Ветивер', 'Ладан', 'Кедр', 'Амбра']
const MOODS = ['Романтичный', 'Деловой', 'Чувственный', 'Свежий', 'Таинственный', 'Уверенный']
const SORTS = [
  { label: 'Новинки', value: 'createdAt-desc' },
  { label: 'Цена: по возрастанию', value: 'price-asc' },
  { label: 'Цена: по убыванию', value: 'price-desc' },
  { label: 'Рейтинг', value: 'rating-desc' },
  { label: 'Название', value: 'name-asc' },
]

function Skeleton() {
  return (
    <div className="luxury-card animate-pulse">
      <div className="skeleton" style={{ height: '280px' }} />
      <div className="p-4 space-y-2">
        <div className="skeleton h-3 w-1/3 rounded" />
        <div className="skeleton h-5 w-2/3 rounded" />
        <div className="skeleton h-4 w-1/4 rounded" />
      </div>
    </div>
  )
}

export default function CatalogPage() {
  const searchParams = useSearchParams()
  const router = useRouter()

  const [page, setPage] = useState(1)
  const [search, setSearch] = useState(searchParams.get('search') ?? '')
  const [brand, setBrand] = useState(searchParams.get('brand') ?? '')
  const [category, setCategory] = useState(searchParams.get('category') ?? '')
  const [gender, setGender] = useState(searchParams.get('gender') ?? '')
  const [sort, setSort] = useState('createdAt-desc')
  const [priceRange, setPriceRange] = useState([0, 200000])
  const [selectedMoods, setSelectedMoods] = useState<string[]>([])
  const [selectedNotes, setSelectedNotes] = useState<string[]>([])
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [isNew] = useState(searchParams.get('new') === 'true')
  const [isBestseller] = useState(searchParams.get('bestseller') === 'true')

  const [sortField, sortOrder] = sort.split('-')

  const queryString = new URLSearchParams({
    page: String(page),
    limit: '24',
    ...(search && { search }),
    ...(brand && { brand }),
    ...(category && { category }),
    ...(gender && { gender }),
    sort: sortField,
    order: sortOrder,
    minPrice: String(priceRange[0]),
    maxPrice: String(priceRange[1]),
    ...(selectedMoods.length && { moods: selectedMoods.join(',') }),
    ...(selectedNotes.length && { notes: selectedNotes.join(',') }),
    ...(isNew && { new: 'true' }),
    ...(isBestseller && { bestseller: 'true' }),
  }).toString()

  const { data, isLoading, isFetching } = useQuery({
    queryKey: ['catalog', queryString],
    queryFn: () => fetch(`/api/products?${queryString}`).then(r => r.json()),
    keepPreviousData: true,
  } as any)

  const clearFilters = () => {
    setSearch(''); setBrand(''); setCategory(''); setGender('')
    setSelectedMoods([]); setSelectedNotes([]); setPriceRange([0, 200000])
    setPage(1)
  }

  const activeFilters = [
    search && `Поиск: "${search}"`,
    brand && `Бренд: ${brand}`,
    category,
    gender,
    ...selectedMoods,
    ...selectedNotes,
  ].filter(Boolean)

  return (
    <div className="max-w-[1400px] mx-auto px-4 lg:px-8 py-10">
      {/* Header */}
      <div className="mb-8">
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(36px, 5vw, 64px)', fontWeight: 400, color: '#1E6B5E' }}>
          {isNew ? 'Новинки' : isBestseller ? 'Бестселлеры' : category ? category : 'Каталог'}
        </h1>
        {data?.pagination?.total && (
          <p style={{ fontFamily: 'var(--font-body)', fontSize: '14px', color: 'rgba(26,26,26,0.5)', marginTop: '4px' }}>
            {data.pagination.total.toLocaleString('ru')} ароматов
          </p>
        )}
      </div>

      {/* Active filters */}
      {activeFilters.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-6">
          {activeFilters.map(f => f && (
            <span key={f} style={{ fontFamily: 'var(--font-body)', fontSize: '12px', color: '#1E6B5E', border: '1px solid #1E6B5E', padding: '4px 12px', display: 'flex', alignItems: 'center', gap: '6px' }}>
              {f}
              <X size={10} style={{ cursor: 'pointer' }} onClick={clearFilters} />
            </span>
          ))}
          <button onClick={clearFilters} style={{ fontFamily: 'var(--font-body)', fontSize: '12px', color: '#C9A96E', textDecoration: 'underline', background: 'none', border: 'none', cursor: 'pointer' }}>
            Сбросить всё
          </button>
        </div>
      )}

      <div className="flex gap-8">
        {/* ── SIDEBAR ──────────────── */}
        <aside className={`${sidebarOpen ? 'fixed inset-0 z-50 overflow-y-auto p-6 pt-16' : 'hidden'} lg:block lg:relative lg:z-auto lg:inset-auto lg:p-0 lg:overflow-visible`}
          style={{ width: sidebarOpen ? '100%' : '260px', flexShrink: 0, background: sidebarOpen ? '#F5EDDC' : 'transparent' }}>

          {sidebarOpen && (
            <button className="absolute top-4 right-4 lg:hidden" onClick={() => setSidebarOpen(false)}>
              <X size={22} color="#1E6B5E" />
            </button>
          )}

          <div className="space-y-8">
            {/* Search */}
            <div>
              <h3 style={{ fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.2em', textTransform: 'uppercase', color: '#C9A96E', marginBottom: '12px' }}>Поиск</h3>
              <input
                type="text"
                placeholder="Аромат, бренд, нота..."
                value={search}
                onChange={e => { setSearch(e.target.value); setPage(1) }}
                className="input-luxury text-sm"
              />
            </div>

            {/* Gender */}
            <div>
              <h3 style={{ fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.2em', textTransform: 'uppercase', color: '#C9A96E', marginBottom: '12px' }}>Для кого</h3>
              {[['', 'Все'], ['FEMALE', 'Для неё'], ['MALE', 'Для него'], ['UNISEX', 'Унисекс']].map(([val, label]) => (
                <label key={val} className="flex items-center gap-3 mb-2 cursor-pointer">
                  <input type="radio" name="gender" checked={gender === val} onChange={() => { setGender(val); setPage(1) }}
                    style={{ accentColor: '#1E6B5E' }}
                  />
                  <span style={{ fontFamily: 'var(--font-body)', fontSize: '14px', color: '#1A1A1A' }}>{label}</span>
                </label>
              ))}
            </div>

            {/* Price */}
            <div>
              <h3 style={{ fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.2em', textTransform: 'uppercase', color: '#C9A96E', marginBottom: '12px' }}>Цена</h3>
              <div className="flex gap-2 mb-2">
                <input type="number" value={priceRange[0]} onChange={e => setPriceRange([+e.target.value, priceRange[1]])}
                  className="input-luxury text-xs" style={{ fontSize: '12px' }} placeholder="от" />
                <input type="number" value={priceRange[1]} onChange={e => setPriceRange([priceRange[0], +e.target.value])}
                  className="input-luxury text-xs" style={{ fontSize: '12px' }} placeholder="до" />
              </div>
              <div className="text-xs mt-1" style={{ fontFamily: 'var(--font-mono)', color: 'rgba(26,26,26,0.5)' }}>
                {formatPrice(priceRange[0])} — {formatPrice(priceRange[1])}
              </div>
            </div>

            {/* Brands */}
            <div>
              <h3 style={{ fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.2em', textTransform: 'uppercase', color: '#C9A96E', marginBottom: '12px' }}>Бренды</h3>
              <div className="space-y-2 max-h-48 overflow-y-auto pr-2">
                {BRANDS.map(b => (
                  <label key={b} className="flex items-center gap-3 cursor-pointer">
                    <input type="checkbox" checked={brand === b.toLowerCase().replace(/ /g, '-')}
                      onChange={() => { setBrand(brand === b.toLowerCase().replace(/ /g, '-') ? '' : b.toLowerCase().replace(/ /g, '-')); setPage(1) }}
                      style={{ accentColor: '#1E6B5E' }}
                    />
                    <span style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: '#1A1A1A' }}>{b}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Moods */}
            <div>
              <h3 style={{ fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.2em', textTransform: 'uppercase', color: '#C9A96E', marginBottom: '12px' }}>Настроение</h3>
              <div className="flex flex-wrap gap-2">
                {MOODS.map(m => (
                  <button key={m}
                    onClick={() => { setSelectedMoods(prev => prev.includes(m) ? prev.filter(x => x !== m) : [...prev, m]); setPage(1) }}
                    style={{
                      fontFamily: 'var(--font-body)', fontSize: '11px', padding: '4px 12px', border: '1px solid',
                      borderColor: selectedMoods.includes(m) ? '#1E6B5E' : 'rgba(201,169,110,0.4)',
                      background: selectedMoods.includes(m) ? '#1E6B5E' : 'transparent',
                      color: selectedMoods.includes(m) ? '#F5EDDC' : '#1A1A1A',
                      cursor: 'pointer', transition: 'all 0.2s',
                    }}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>

            {/* Notes */}
            <div>
              <h3 style={{ fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.2em', textTransform: 'uppercase', color: '#C9A96E', marginBottom: '12px' }}>Ноты</h3>
              <div className="flex flex-wrap gap-2">
                {NOTES.map(n => (
                  <button key={n}
                    onClick={() => { setSelectedNotes(prev => prev.includes(n) ? prev.filter(x => x !== n) : [...prev, n]); setPage(1) }}
                    style={{
                      fontFamily: 'var(--font-body)', fontSize: '11px', padding: '4px 12px', border: '1px solid',
                      borderColor: selectedNotes.includes(n) ? '#C9A96E' : 'rgba(201,169,110,0.4)',
                      background: selectedNotes.includes(n) ? '#C9A96E' : 'transparent',
                      color: selectedNotes.includes(n) ? 'white' : '#1A1A1A',
                      cursor: 'pointer', transition: 'all 0.2s',
                    }}
                  >
                    {n}
                  </button>
                ))}
              </div>
            </div>

            <button onClick={clearFilters} className="btn-primary w-full text-center" style={{ fontSize: '11px' }}>
              Сбросить фильтры
            </button>
          </div>
        </aside>

        {/* ── MAIN GRID ─────────────── */}
        <div className="flex-1 min-w-0">
          {/* Sort bar */}
          <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
            <button className="lg:hidden flex items-center gap-2 btn-primary" style={{ fontSize: '11px' }} onClick={() => setSidebarOpen(true)}>
              <SlidersHorizontal size={14} /> Фильтры
            </button>

            <select
              value={sort}
              onChange={e => { setSort(e.target.value); setPage(1) }}
              className="input-luxury text-sm ml-auto"
              style={{ width: 'auto', fontSize: '13px', cursor: 'pointer' }}
            >
              {SORTS.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
            </select>
          </div>

          {/* Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4 lg:gap-6">
            {isLoading
              ? Array(24).fill(0).map((_, i) => <Skeleton key={i} />)
              : data?.products?.map((p: any) => <ProductCard key={p.id} product={p} />)
            }
          </div>

          {isFetching && !isLoading && (
            <div className="text-center py-8" style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: '#C9A96E' }}>
              Загрузка...
            </div>
          )}

          {/* Pagination */}
          {data?.pagination && data.pagination.pages > 1 && (
            <div className="flex items-center justify-center gap-3 mt-12 flex-wrap">
              <button
                disabled={page === 1}
                onClick={() => setPage(p => p - 1)}
                className="btn-primary"
                style={{ fontSize: '11px', opacity: page === 1 ? 0.4 : 1 }}
              >
                ← Назад
              </button>

              {Array.from({ length: Math.min(data.pagination.pages, 10) }, (_, i) => {
                const p = i + 1
                return (
                  <button key={p} onClick={() => setPage(p)}
                    style={{
                      width: '36px', height: '36px', border: '1px solid',
                      borderColor: page === p ? '#1E6B5E' : 'rgba(201,169,110,0.4)',
                      background: page === p ? '#1E6B5E' : 'transparent',
                      color: page === p ? '#F5EDDC' : '#1A1A1A',
                      fontFamily: 'var(--font-mono)', fontSize: '13px',
                      cursor: 'pointer',
                    }}
                  >
                    {p}
                  </button>
                )
              })}

              {data.pagination.pages > 10 && <span style={{ fontFamily: 'var(--font-mono)', fontSize: '13px' }}>... {data.pagination.pages}</span>}

              <button
                disabled={page === data.pagination.pages}
                onClick={() => setPage(p => p + 1)}
                className="btn-primary"
                style={{ fontSize: '11px', opacity: page === data.pagination.pages ? 0.4 : 1 }}
              >
                Вперёд →
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
