import { Header } from '@/components/layout/Header'
import { Footer } from '@/components/layout/Footer'
import { Ticker } from '@/components/layout/Ticker'

export default function ShopLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col" style={{ background: '#F5EDDC' }}>
      <Ticker />
      <Header />
      <main className="flex-1">
        {children}
      </main>
      <Footer />
    </div>
  )
}
