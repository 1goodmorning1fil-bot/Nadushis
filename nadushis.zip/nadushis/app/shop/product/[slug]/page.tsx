'use client'

import { useParams } from 'next/navigation'
import { useQuery } from '@tanstack/react-query'
import Image from 'next/image'
import { useState } from 'react'
import { useCart, useFavorites } from '@/lib/store'
import { formatPrice, formatConcentration, formatGender } from '@/lib/utils'
import toast from 'react-hot-toast'
import { Heart, ShoppingBag, Share2, Star } from 'lucide-react'

// ─── Fragrance Pyramid ─────────────────────────────────────────────
function FragrancePyramid({ top, heart, base }: { top: string[]; heart: string[]; base: string[] }) {
  return (
    <div className="my-8">
      <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '24px', color: '#1E6B5E', marginBottom: '24px', textAlign: 'center' }}>
        Пирамида аромата
      </h3>
      <div className="flex flex-col items-center gap-2">
        {/* Top */}
        <div style={{ width: '60%', background: 'linear-gradient(135deg, #1E6B5E, #2A8F7F)', padding: '16px', textAlign: 'center', clipPath: 'polygon(15% 0%, 85% 0%, 100% 100%, 0% 100%)' }}>
          <div style={{ fontFamily: 'var(--font-body)', fontSize: '10px', letterSpacing: '0.2em', textTransform: 'uppercase', color: 'rgba(245,237,220,0.7)', marginBottom: '6px' }}>Верхние ноты</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '15px', color: '#F5EDDC' }}>{top.join(' · ')}</div>
        </div>
        {/* Heart */}
        <div style={{ width: '80%', background: 'linear-gradient(135deg, #C9A96E, #DFC08E)', padding: '16px', textAlign: 'center' }}>
          <div style={{ fontFamily: 'var(--font-body)', fontSize: '10px', letterSpacing: '0.2em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.7)', marginBottom: '6px' }}>Сердечные ноты</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '15px', color: 'white' }}>{heart.join(' · ')}</div>
        </div>
        {/* Base */}
        <div style={{ width: '100%', background: 'linear-gradient(135deg, #134940, #1E6B5E)', padding: '16px', textAlign: 'center', clipPath: 'polygon(0% 0%, 100% 0%, 85% 100%, 15% 100%)' }}>
          <div style={{ fontFamily: 'var(--font-body)', fontSize: '10px', letterSpacing: '0.2em', textTransform: 'uppercase', color: 'rgba(245,237,220,0.7)', marginBottom: '6px' }}>Базовые ноты</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: '15px', color: '#F5EDDC' }}>{base.join(' · ')}</div>
        </div>
      </div>
    </div>
  )
}

export default function ProductPage() {
  const { slug } = useParams<{ slug: string }>()
  const { add } = useCart()
  const { toggle, has } = useFavorites()

  const [selectedVolume, setSelectedVolume] = useState<number | null>(null)
  const [qty, setQty] = useState(1)
  const [activeImage, setActiveImage] = useState(0)
  const [activeTab, setActiveTab] = useState<'desc' | 'pyramid' | 'reviews'>('desc')

  const { data: product, isLoading } = useQuery({
    queryKey: ['product', slug],
    queryFn: () => fetch(`/api/products/${slug}`).then(r => r.json()),
  })

  if (isLoading) return (
    <div className="max-w-7xl mx-auto px-6 py-20 grid grid-cols-1 md:grid-cols-2 gap-16">
      <div className="skeleton" style={{ height: '600px' }} />
      <div className="space-y-4">
        {Array(6).fill(0).map((_, i) => <div key={i} className="skeleton h-8 rounded" />)}
      </div>
    </div>
  )

  if (!product || product.error) return (
    <div className="text-center py-32" style={{ fontFamily: 'var(--font-display)', fontSize: '24px', color: '#1E6B5E' }}>
      Товар не найден
    </div>
  )

  const vol = selectedVolume ?? product.volume[0]
  const isFav = has(product.id)

  const handleAddToCart = () => {
    add({ id: product.id, name: product.name, brand: product.brand.name, price: Number(product.price), image: product.images[0] ?? '', volume: vol, qty, slug: product.slug })
    toast.success('Добавлено в корзину!')
  }

  const stars = Math.round(Number(product.rating))

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      {/* Breadcrumbs */}
      <nav className="mb-8" style={{ fontFamily: 'var(--font-body)', fontSize: '12px', color: 'rgba(26,26,26,0.5)' }}>
        <a href="/shop" style={{ color: '#1E6B5E' }}>Главная</a>
        <span className="mx-2">·</span>
        <a href="/shop/catalog" style={{ color: '#1E6B5E' }}>Каталог</a>
        <span className="mx-2">·</span>
        <span>{product.brand.name}</span>
        <span className="mx-2">·</span>
        <span style={{ color: '#1A1A1A' }}>{product.name}</span>
      </nav>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
        {/* ── Images ── */}
        <div>
          <div className="relative overflow-hidden mb-4" style={{ aspectRatio: '3/4', background: '#F5EDDC' }}>
            {product.images[activeImage] ? (
              <Image src={product.images[activeImage]} alt={product.name} fill className="object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <span style={{ fontFamily: 'var(--font-display)', fontSize: '80px', color: '#C9A96E', opacity: 0.3 }}>ND</span>
              </div>
            )}
            {product.newArrival && (
              <span className="absolute top-4 left-4" style={{ background: '#1E6B5E', color: '#F5EDDC', fontSize: '10px', fontFamily: 'var(--font-body)', letterSpacing: '0.15em', textTransform: 'uppercase', padding: '4px 10px' }}>
                Новинка
              </span>
            )}
          </div>
          {product.images.length > 1 && (
            <div className="flex gap-3">
              {product.images.map((img: string, i: number) => (
                <button key={i} onClick={() => setActiveImage(i)}
                  className="relative overflow-hidden flex-shrink-0"
                  style={{ width: '80px', height: '80px', border: `2px solid ${activeImage === i ? '#1E6B5E' : 'transparent'}`, background: '#F5EDDC' }}>
                  <Image src={img} alt="" fill className="object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* ── Info ── */}
        <div>
          <div className="mb-2" style={{ fontFamily: 'var(--font-body)', fontSize: '12px', letterSpacing: '0.2em', textTransform: 'uppercase', color: '#C9A96E' }}>
            {product.brand.name}
          </div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 'clamp(28px, 4vw, 48px)', fontWeight: 400, color: '#1A1A1A', lineHeight: 1.1, marginBottom: '12px' }}>
            {product.name}
          </h1>

          {/* Rating */}
          <div className="flex items-center gap-2 mb-4">
            <div className="flex">
              {Array(5).fill(0).map((_, i) => (
                <Star key={i} size={14} fill={i < stars ? '#C9A96E' : 'none'} color={i < stars ? '#C9A96E' : '#ccc'} />
              ))}
            </div>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: '12px', color: 'rgba(26,26,26,0.5)' }}>
              {Number(product.rating).toFixed(1)} ({product.reviewCount} отзывов)
            </span>
          </div>

          {/* Tags */}
          <div className="flex flex-wrap gap-2 mb-6">
            {[formatGender(product.gender), formatConcentration(product.concentration), product.category.name].map(tag => (
              <span key={tag} style={{ fontFamily: 'var(--font-body)', fontSize: '11px', color: '#1E6B5E', border: '1px solid rgba(30,107,94,0.3)', padding: '3px 10px', letterSpacing: '0.05em' }}>
                {tag}
              </span>
            ))}
          </div>

          {/* Price */}
          <div className="flex items-baseline gap-4 mb-8">
            <span style={{ fontFamily: 'var(--font-display)', fontSize: '42px', fontWeight: 600, color: '#1E6B5E' }}>
              {formatPrice(product.price)}
            </span>
            {product.comparePrice && Number(product.comparePrice) > Number(product.price) && (
              <span style={{ fontFamily: 'var(--font-body)', fontSize: '20px', color: 'rgba(26,26,26,0.35)', textDecoration: 'line-through' }}>
                {formatPrice(product.comparePrice)}
              </span>
            )}
          </div>

          {/* Volume */}
          <div className="mb-6">
            <label style={{ fontFamily: 'var(--font-body)', fontSize: '11px', letterSpacing: '0.2em', textTransform: 'uppercase', color: '#C9A96E', display: 'block', marginBottom: '12px' }}>
              Объём
            </label>
            <div className="flex gap-3 flex-wrap">
              {product.volume.map((v: number) => (
                <button key={v} onClick={() => setSelectedVolume(v)}
                  style={{
                    padding: '10px 20px',
                    border: `1px solid ${vol === v ? '#1E6B5E' : 'rgba(201,169,110,0.4)'}`,
                    background: vol === v ? '#1E6B5E' : 'transparent',
                    color: vol === v ? '#F5EDDC' : '#1A1A1A',
                    fontFamily: 'var(--font-mono)', fontSize: '13px',
                    cursor: 'pointer', transition: 'all 0.2s',
                  }}
                >
                  {v} мл
                </button>
              ))}
            </div>
          </div>

          {/* Qty + Add */}
          <div className="flex gap-3 mb-6">
            <div className="flex items-center border" style={{ borderColor: 'rgba(201,169,110,0.4)' }}>
              <button onClick={() => setQty(q => Math.max(1, q - 1))}
                style={{ width: '44px', height: '52px', background: 'none', border: 'none', fontSize: '18px', cursor: 'pointer', color: '#1E6B5E' }}>−</button>
              <span style={{ width: '44px', textAlign: 'center', fontFamily: 'var(--font-mono)', fontSize: '16px' }}>{qty}</span>
              <button onClick={() => setQty(q => q + 1)}
                style={{ width: '44px', height: '52px', background: 'none', border: 'none', fontSize: '18px', cursor: 'pointer', color: '#1E6B5E' }}>+</button>
            </div>

            <button onClick={handleAddToCart} disabled={!product.inStock}
              className="btn-primary flex-1 flex items-center justify-center gap-2"
              style={{ opacity: product.inStock ? 1 : 0.5, cursor: product.inStock ? 'pointer' : 'not-allowed' }}>
              <ShoppingBag size={16} />
              {product.inStock ? 'Добавить в корзину' : 'Нет в наличии'}
            </button>

            <button onClick={() => toggle({ id: product.id, name: product.name, brand: product.brand.name, price: Number(product.price), image: product.images[0] ?? '', slug: product.slug })}
              style={{ width: '52px', height: '52px', border: `1px solid ${isFav ? '#1E6B5E' : 'rgba(201,169,110,0.4)'}`, background: isFav ? '#1E6B5E' : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', transition: 'all 0.2s' }}>
              <Heart size={18} color={isFav ? '#F5EDDC' : '#1E6B5E'} fill={isFav ? '#F5EDDC' : 'none'} />
            </button>
          </div>

          {/* Delivery info */}
          <div className="p-4 space-y-2" style={{ background: 'rgba(30,107,94,0.05)', border: '1px solid rgba(30,107,94,0.1)' }}>
            {[['🚚', 'Бесплатная доставка от 5 000 ₽'], ['🎁', 'Подарочная упаковка'], ['↩', 'Возврат в течение 30 дней'], ['✓', '100% оригинальная продукция']].map(([icon, text]) => (
              <div key={text} className="flex items-center gap-3">
                <span style={{ fontSize: '14px' }}>{icon}</span>
                <span style={{ fontFamily: 'var(--font-body)', fontSize: '13px', color: 'rgba(26,26,26,0.7)' }}>{text}</span>
              </div>
            ))}
          </div>

          {/* Moods & seasons */}
          {(product.moods.length > 0 || product.season.length > 0) && (
            <div className="mt-6 flex flex-wrap gap-2">
              {product.moods.map((m: string) => (
                <span key={m} style={{ fontFamily: 'var(--font-body)', fontSize: '11px', color: '#C9A96E', border: '1px solid rgba(201,169,110,0.4)', padding: '2px 10px' }}>{m}</span>
              ))}
              {product.season.map((s: string) => (
                <span key={s} style={{ fontFamily: 'var(--font-body)', fontSize: '11px', color: 'rgba(26,26,26,0.5)', border: '1px solid rgba(26,26,26,0.15)', padding: '2px 10px' }}>{s}</span>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ── Tabs ── */}
      <div className="mt-16">
        <div className="flex border-b" style={{ borderColor: 'rgba(201,169,110,0.3)' }}>
          {[['desc', 'Описание'], ['pyramid', 'Пирамида аромата'], ['reviews', `Отзывы (${product.reviewCount})`]].map(([tab, label]) => (
            <button key={tab} onClick={() => setActiveTab(tab as any)}
              style={{
                padding: '14px 24px',
                fontFamily: 'var(--font-body)', fontSize: '13px', letterSpacing: '0.1em', textTransform: 'uppercase',
                borderBottom: `2px solid ${activeTab === tab ? '#1E6B5E' : 'transparent'}`,
                color: activeTab === tab ? '#1E6B5E' : 'rgba(26,26,26,0.5)',
                background: 'none', border: 'none', borderBottom: `2px solid ${activeTab === tab ? '#1E6B5E' : 'transparent'}`,
                cursor: 'pointer', transition: 'all 0.2s',
              }}>
              {label}
            </button>
          ))}
        </div>

        <div className="py-10 max-w-3xl">
          {activeTab === 'desc' && (
            <div>
              {product.story && (
                <blockquote className="mb-6 pl-6" style={{ borderLeft: '3px solid #C9A96E' }}>
                  <p style={{ fontFamily: 'var(--font-display)', fontSize: '20px', fontStyle: 'italic', color: '#1E6B5E', lineHeight: 1.6 }}>
                    {product.story}
                  </p>
                </blockquote>
              )}
              <p style={{ fontFamily: 'var(--font-body)', fontSize: '15px', color: 'rgba(26,26,26,0.75)', lineHeight: '1.9' }}>
                {product.description}
              </p>
              {product.occasions.length > 0 && (
                <div className="mt-6">
                  <span style={{ fontFamily: 'var(--font-body)', fontSize: '12px', letterSpacing: '0.15em', textTransform: 'uppercase', color: '#C9A96E' }}>Повод: </span>
                  <span style={{ fontFamily: 'var(--font-body)', fontSize: '14px', color: '#1A1A1A' }}>{product.occasions.join(', ')}</span>
                </div>
              )}
            </div>
          )}

          {activeTab === 'pyramid' && (
            <FragrancePyramid top={product.topNotes} heart={product.heartNotes} base={product.baseNotes} />
          )}

          {activeTab === 'reviews' && (
            <div>
              {product.reviews.length === 0 ? (
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '20px', color: 'rgba(26,26,26,0.4)', textAlign: 'center', padding: '40px 0' }}>
                  Пока нет отзывов
                </div>
              ) : (
                <div className="space-y-6">
                  {product.reviews.map((r: any) => (
                    <div key={r.id} className="p-6" style={{ border: '1px solid rgba(201,169,110,0.2)' }}>
                      <div className="flex items-center gap-3 mb-3">
                        <span style={{ fontFamily: 'var(--font-body)', fontSize: '14px', fontWeight: 600, color: '#1A1A1A' }}>{r.author}</span>
                        <div className="flex">
                          {Array(5).fill(0).map((_, i) => <Star key={i} size={12} fill={i < r.rating ? '#C9A96E' : 'none'} color={i < r.rating ? '#C9A96E' : '#ccc'} />)}
                        </div>
                        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: 'rgba(26,26,26,0.4)' }}>
                          {new Date(r.createdAt).toLocaleDateString('ru')}
                        </span>
                      </div>
                      <p style={{ fontFamily: 'var(--font-body)', fontSize: '14px', color: 'rgba(26,26,26,0.7)', lineHeight: 1.7 }}>{r.text}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
